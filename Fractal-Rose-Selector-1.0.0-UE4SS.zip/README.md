# Fractal Rose Selector 1.0.0

Choose which Fractal Rose variant grows from regular and hybrid seeds, regardless of which planet you're on.

No changes to drop rates, seed counts or growth speed.


## Install

- **(RECOMMENDED)** Install with [Nexus Mods Vortex](https://www.nexusmods.com/vortex), which automatically installs required extensions for Astroneer mods.
- Manual installation:
    1. Download the latest [UE4SS experimental .zip file](https://github.com/UE4SS-RE/RE-UE4SS/releases/tag/experimental-latest) (scroll to the bottom under assets).
    2. In Steam, right-click Astroneer → Manage → Browse local files. Open `Astro\Binaries\Win64`.
    3. Extract the UE4SS .zip content into `Astro\Binaries\Win64`.
    4. Extract the mod's zip `Fractal-Rose-Selector-1.0.0-UE4SS.zip` into `Astro\Binaries\Win64\ue4ss\Mods`.
    5. It should look something like this: `ASTRONEER\Astro\Binaries\Win64\ue4ss\Mods\FractalRoseSelector`.

If you're updating, close the game and replace the old `FractalRoseSelector` folder. If you still have the original `FractalRose` folder, remove it too. Keep only one version enabled.


## Rose selection

Normal rose selection is used by default. Pick a variant using the in-game console.

Press F10 once to open the console input field or twice to see the full console.

Available commands:

```text
fractalrose calidor
fractalrose status
fractalrose reset
```

- `fractalrose calidor`: select Calidor roses for new plantings.
- `fractalrose status`: show the selection for new plantings.
- `fractalrose reset`: go back to normal selection for new plantings.
- `fractalrose`: show help.

`rose` works as an alias to `fractalrose`, as in `rose calidor`, `rose status` or `rose reset`. Replies appear in the in-game console.

Available variants:

```text
sylva, desolo, vesania, novus, calidor, glacio, atrox, chronos
```

`chronos` is the special Chronos rose. Planet names are case-insensitive.

Growing roses keep the choice they started with. Changing the command or resetting it affects new plantings only. Fully grown roses stay as they are.

> [!IMPORTANT]
> The selection and per-seed locks reset when you close the game. Unfinished seeds loaded after relaunch use the game's normal selection.

Use in single-player or as the host. Multiplayer has not been tested.


## Something didn't work?

Send me `Astro\Binaries\Win64\ue4ss\UE4SS.log` with what you tried, what you expected and what happened (screenshots optional but will help). A screenshot of `rose status` will help too.
